def display_message():
    print("Press Ctrl+C to stop!")
    display_message()

display_message()
