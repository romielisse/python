SELECT name, year 
FROM Movie
WHERE categoryID = 3
ORDER BY year DESC
